# algoritmos/busca_largura.py - BFS

from collections import deque
from typing import List, Tuple, Set
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from configuracoes import TIPO_LIVRE, TIPO_BOMBA, TIPO_TESOURO, TIPO_BANDEIRA

class BuscaEmLargura:
    """Busca em Largura"""
    
    def __init__(self, tabuleiro):
        self.tabuleiro = tabuleiro
    
    def obter_candidatas(self, posicao: Tuple[int, int], visitadas: Set, grupo: int, historico_recente: List = None, imunidades: int = 0) -> List[Tuple[int, int]]:
        """
        Prioriza células NÃO visitadas
        - Retorna células NOVAS adjacentes primeiro
        - Se não há novas, permite revisitar células LIVRES já exploradas
        - Se agente tem imunidade E não há candidatas, permite bombas
        """
        candidatas_novas = []
        candidatas_livres_revisitadas = []
        candidatas_bombas = []
        
        if historico_recente is None:
            historico_recente = []
        
        vizinhos = self.tabuleiro.obter_vizinhos(posicao)
        
        for vizinho in vizinhos:
            if vizinho in self.tabuleiro.bombas_desativadas.get(grupo, set()):
                continue
            
            vx, vy = vizinho
            tipo_vizinho = self.tabuleiro.matriz[vx][vy]
            
            if vizinho not in visitadas:
                if tipo_vizinho == TIPO_BOMBA:
                    candidatas_bombas.append(vizinho)
                else:
                    candidatas_novas.append(vizinho)
            
            elif vizinho in visitadas and tipo_vizinho == TIPO_LIVRE:
                if len(historico_recente) < 2 or vizinho not in historico_recente[-2:]:
                    candidatas_livres_revisitadas.append(vizinho)
        
        if candidatas_novas:
            return candidatas_novas
        
        if candidatas_livres_revisitadas:
            print(f"  DEBUG: Usando livres revisitadas: {candidatas_livres_revisitadas}")
            return candidatas_livres_revisitadas
        
        if imunidades > 0 and candidatas_bombas:
            print(f"  DEBUG: Usando bomba com imunidade: {candidatas_bombas[0]}")
            return candidatas_bombas[:1]
        
        print(f"  DEBUG: SEM CANDIDATAS em {posicao}! Vizinhos: {len(vizinhos)}, Visitadas: {len(visitadas)}")
        return []